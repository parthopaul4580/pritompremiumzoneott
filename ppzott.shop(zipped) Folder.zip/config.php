<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// -------------------------------------------------------------
// cPanel Database Configuration (Change these to match your cPanel DB)
// -------------------------------------------------------------
define('DB_HOST', 'localhost');
define('DB_USER', 'YOUR_CPANEL_DB_USER'); 
define('DB_PASS', 'YOUR_CPANEL_DB_PASSWORD'); 
define('DB_NAME', 'YOUR_CPANEL_DB_NAME'); 

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($conn->connect_error) {
    die("Database Connection Failed: " . $conn->connect_error);
}
$conn->set_charset("utf8mb4");

// -------------------------------------------------------------
// Payment Gateway Config (InfinityPay Verified)
// -------------------------------------------------------------
define('BRAND_KEY', 'yu7JCZ9qZUEsnp4jTJhy1JsbYwAoMhgT7mjbTdyMXGiBfVtFwR');
define('INFINITY_PAY_URL', 'https://infinitypay.infinitydigitalshop.com/api/checkout');

// -------------------------------------------------------------
// Admin Portal Credentials
// -------------------------------------------------------------
define('ADMIN_USER', 'prirom');
define('ADMIN_EMAIL', 'admin@Gmail.com');
define('ADMIN_PASS', '123456');

// -------------------------------------------------------------
// Business & Social Contact Info
// -------------------------------------------------------------
$website_name = "Pritom Premium Zone-OTT";
$domain_name = "www.ppzott.shop";
$whatsapp_num = "+8801581694019";
$contact_num = "+8801581694019";
$contact_email = "pritompremiumzone@Gmail.com";
$address = "Wazirpur, Barisal";
$owner_name = "Pritom Paul";

$main_website = "https://www.pritompremiumzone.com";
$fb_page = "https://facebook.com/pritomprimiumzoneott";
$insta_page = "https://www.instagram.com/pritompremiumzone1?igsh=MXJjbnZ0OGJhaTJrMA==";
$wa_group = "https://chat.whatsapp.com/Hv9sTdpQk4C9olyTNZqbUu";
$tg_group = "https://t.me/pritompremiumzone";
?>
