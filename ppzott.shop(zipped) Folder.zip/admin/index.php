<?php
include '../config.php';

// Logout Handler
if (isset($_GET['logout'])) {
    unset($_SESSION['admin_logged_in']);
    session_destroy();
    header("Location: index.php");
    exit;
}

// Authentication Logic (Supports both Username & Gmail)
$error_msg = "";
if (isset($_POST['login'])) {
    $user_or_email = trim($_POST['username_or_email']);
    $password = trim($_POST['password']);

    if (($user_or_email === ADMIN_USER || $user_or_email === ADMIN_EMAIL) && $password === ADMIN_PASS) {
        $_SESSION['admin_logged_in'] = true;
    } else {
        $error_msg = "ভুল ইউজারনেম/ইমেইল অথবা পাসওয়ার্ড দিয়েছেন!";
    }
}

// View Controller Check
if (!isset($_SESSION['admin_logged_in'])) {
    ?>
    <!DOCTYPE html>
    <html lang="bn">
    <head>
        <meta charset="UTF-8">
        <title>Admin Authentication | Pritom Premium Zone</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    </head>
    <body class="bg-slate-950 text-gray-100 flex items-center justify-center min-h-screen p-4">
        <div class="max-w-md w-full bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl relative">
            <div class="absolute top-0 inset-x-0 h-1.5 bg-amber-500"></div>
            <h2 class="text-2xl font-black text-white text-center mb-1 text-transparent bg-clip-text bg-gradient-to-r from-amber-400 to-orange-400">ADMIN PANEL LOGIN</h2>
            <p class="text-xs text-gray-500 text-center mb-6">লগইন করতে ইউজারনেম অথবা জিমেইল ব্যবহার করুন।</p>
            
            <?php if($error_msg): ?>
                <div class="bg-red-500/10 border border-red-500/30 text-red-400 p-3 rounded-xl text-xs mb-4 flex items-center gap-2">
                    <i class="fas fa-exclamation-triangle"></i> <?php echo $error_msg; ?>
                </div>
            <?php endif; ?>

            <form action="index.php" method="POST" class="space-y-4">
                <div>
                    <label class="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-1">Username or Gmail</label>
                    <input type="text" name="username_or_email" required class="w-full bg-slate-950 border border-slate-800 rounded-xl py-2.5 px-4 text-white text-sm focus:outline-none focus:border-amber-500" placeholder="prirom অথবা admin@Gmail.com">
                </div>
                <div>
                    <label class="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-1">Password</label>
                    <input type="password" name="password" required class="w-full bg-slate-950 border border-slate-800 rounded-xl py-2.5 px-4 text-white text-sm focus:outline-none focus:border-amber-500" placeholder="••••••">
                </div>
                <button type="submit" name="login" class="w-full bg-amber-500 hover:bg-amber-600 text-slate-950 font-black py-3 rounded-xl transition-colors cursor-pointer">
                    Dashboard এ প্রবেশ করুন
                </button>
            </form>
        </div>
    </body>
    </html>
    <?php
    exit;
}

// Action: Create/Add Product
if (isset($_POST['add_product'])) {
    $name = $conn->real_escape_string($_POST['name']);
    $image = $conn->real_escape_string($_POST['image']);
    $price = floatval($_POST['price']);
    $duration = $conn->real_escape_string($_POST['duration']);

    $conn->query("INSERT INTO products (name, image, price, duration) VALUES ('$name', '$image', $price, '$duration')");
    header("Location: index.php?success=1");
    exit;
}

// Action: Remove/Delete Product
if (isset($_GET['delete_id'])) {
    $did = intval($_GET['delete_id']);
    $conn->query("DELETE FROM products WHERE id=$did");
    header("Location: index.php?deleted=1");
    exit;
}

$all_products = $conn->query("SELECT * FROM products ORDER BY id DESC");
$all_orders = $conn->query("SELECT * FROM orders ORDER BY id DESC");
?>
<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Controls | Pritom Premium Zone</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-slate-950 text-gray-100 min-h-screen p-4 sm:p-6">

    <div class="container mx-auto">
        <!-- Dashboard Top Header Bar -->
        <div class="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-6 mb-8 flex flex-col sm:flex-row justify-between items-center gap-4">
            <div>
                <h1 class="text-xl sm:text-2xl font-black text-amber-400">Pritom Premium Zone Dashboard</h1>
                <p class="text-xs text-gray-400">আপনি এখান থেকে যেকোনো প্রোডাক্ট এড এবং রিমুভ করতে পারবেন সম্পূর্ণ ডাইনামিকভাবে।</p>
            </div>
            <a href="index.php?logout=1" class="bg-red-600 hover:bg-red-700 text-white font-bold px-4 py-2 rounded-xl text-sm transition-colors">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <!-- Add New Product Column Form -->
            <div class="bg-slate-900 border border-slate-800 rounded-2xl p-5 h-fit">
                <h2 class="text-base font-bold text-white mb-4 flex items-center gap-2">
                    <i class="fas fa-plus-circle text-green-400"></i> নতুন প্রোডাক্ট যোগ করুন
                </h2>
                
                <form action="index.php" method="POST" class="space-y-4">
                    <div>
                        <label class="block text-xs font-bold text-gray-400 mb-1">প্রোডাক্টের নাম</label>
                        <input type="text" name="name" required placeholder="যেমন: Netflix UHD Premium" class="w-full bg-slate-950 border border-slate-800 rounded-xl py-2 px-3 text-white text-sm focus:outline-none focus:border-amber-500">
                    </div>
                    <div>
                        <label class="block text-xs font-bold text-gray-400 mb-1">ছবির লিংক (Direct URL)</label>
                        <input type="text" name="image" required placeholder="https://link.com/photo.jpg" class="w-full bg-slate-950 border border-slate-800 rounded-xl py-2 px-3 text-white text-sm focus:outline-none focus:border-amber-500">
                    </div>
                    <div>
                        <label class="block text-xs font-bold text-gray-400 mb-1">মূল্য (৳)</label>
                        <input type="number" step="0.01" name="price" required placeholder="250" class="w-full bg-slate-950 border border-slate-800 rounded-xl py-2 px-3 text-white text-sm focus:outline-none focus:border-amber-500">
                    </div>
                    <div>
                        <label class="block text-xs font-bold text-gray-400 mb-1">প্যাকেজ মেয়াদ (Duration)</label>
                        <select name="duration" class="w-full bg-slate-950 border border-slate-800 rounded-xl py-2 px-3 text-white text-sm focus:outline-none focus:border-amber-500">
                            <option value="1">১ মাস</option>
                            <option value="3">৩ মাস</option>
                            <option value="6">৬ মাস</option>
                            <option value="12">১২ মাস</option>
                            <option value="24">২৪ মাস</option>
                        </select>
                    </div>
                    <button type="submit" name="add_product" class="w-full bg-green-500 hover:bg-green-600 text-slate-950 font-black py-2.5 rounded-xl transition-colors mt-2 cursor-pointer">
                        Add to Live Website
                    </button>
                </form>
            </div>

            <!-- Existing Products View List Grid/Table -->
            <div class="bg-slate-900 border border-slate-800 rounded-2xl p-5 lg:col-span-2">
                <h2 class="text-base font-bold text-white mb-4 flex items-center gap-2">
                    <i class="fas fa-list text-amber-400"></i> চলমান প্রোডাক্ট সমূহ
                </h2>
                
                <div class="overflow-x-auto">
                    <table class="w-full text-left text-xs whitespace-nowrap">
                        <thead>
                            <tr class="border-b border-slate-800 text-gray-400">
                                <th class="pb-3 font-bold uppercase">আইটেম ছবি</th>
                                <th class="pb-3 font-bold uppercase pl-4">নাম</th>
                                <th class="pb-3 font-bold uppercase pl-4">মেয়াদ</th>
                                <th class="pb-3 font-bold uppercase pl-4">মূল্য</th>
                                <th class="pb-3 font-bold uppercase text-center">ব্যবস্থাপনা</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-800/50">
                            <?php if($all_products->num_rows > 0): ?>
                                <?php while($p = $all_products->fetch_assoc()): ?>
                                    <tr>
                                        <td class="py-3"><img src="<?php echo htmlspecialchars($p['image']); ?>" class="w-10 h-10 object-cover rounded-lg border border-slate-800"></td>
                                        <td class="py-3 pl-4 font-bold text-white"><?php echo htmlspecialchars($p['name']); ?></td>
                                        <td class="py-3 pl-4 text-amber-400 font-medium"><?php echo $p['duration']; ?> মাস</td>
                                        <td class="py-3 pl-4 text-green-400 font-bold">৳<?php echo number_format($p['price'], 2); ?></td>
                                        <td class="py-3 text-center">
                                            <a href="index.php?delete_id=<?php echo $p['id']; ?>" onclick="return confirm('আপনি কি নিশ্চিতভাবে এই সাবস্ক্রিপশন প্রোডাক্টটি রিমুভ করতে চান?')" class="bg-red-500/10 border border-red-500/20 text-red-400 hover:bg-red-500 hover:text-white px-3 py-1 rounded-md transition-all text-xs font-bold inline-block">
                                                রিমুভ করুন
                                            </a>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="5" class="py-6 text-center text-gray-500">কোনো প্রোডাক্ট পাওয়া যায়নি।</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Orders Logs Management Track Block -->
        <div class="bg-slate-900 border border-slate-800 rounded-2xl p-5 mt-8">
            <h2 class="text-base font-bold text-white mb-4 flex items-center gap-2">
                <i class="fas fa-shopping-bag text-orange-400"></i> সাম্প্রতিক ভেরিফাইড সেলস হিস্টোরি (Orders)
            </h2>
            <div class="overflow-x-auto">
                <table class="w-full text-left text-xs whitespace-nowrap">
                    <thead>
                        <tr class="border-b border-slate-800 text-gray-400">
                            <th class="pb-3 font-bold uppercase">অর্ডার নাম্বার</th>
                            <th class="pb-3 font-bold uppercase pl-4">কাস্টমার</th>
                            <th class="pb-3 font-bold uppercase pl-4">প্রোডাক্ট</th>
                            <th class="pb-3 font-bold uppercase pl-4">মূল্য</th>
                            <th class="pb-3 font-bold uppercase pl-4">Transaction ID</th>
                            <th class="pb-3 font-bold uppercase pl-4">সময় ও তারিখ</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-800/50 text-gray-300">
                        <?php if($all_orders->num_rows > 0): ?>
                            <?php while($o = $all_orders->fetch_assoc()): ?>
                                <tr>
                                    <td class="py-3 font-mono font-bold text-amber-400"><?php echo $o['order_number']; ?></td>
                                    <td class="py-3 pl-4">
                                        <div class="font-bold text-white"><?php echo htmlspecialchars($o['customer_name']); ?></div>
                                        <div class="text-slate-500 text-[10px]"><?php echo $o['phone']; ?> | <?php echo $o['email']; ?></div>
                                    </td>
                                    <td class="py-3 pl-4"><?php echo htmlspecialchars($o['product_name']); ?> (<?php echo $o['duration']; ?> মাস)</td>
                                    <td class="py-3 pl-4 text-green-400 font-bold">৳<?php echo number_format($o['price'], 2); ?></td>
                                    <td class="py-3 pl-4 font-mono bg-slate-950/40 text-xs px-2 py-1 rounded border border-slate-800/30 w-fit text-gray-400"><?php echo $o['trx_id']; ?></td>
                                    <td class="py-3 pl-4 text-gray-500"><?php echo date("d M Y, h:i A", strtotime($o['order_time'])); ?></td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="py-6 text-center text-gray-500">এখনো কোনো অর্ডার সম্পন্ন হয়নি।</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</body>
</html>
