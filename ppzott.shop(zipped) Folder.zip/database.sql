-- Pritom Premium Zone-OTT Database Setup
CREATE TABLE IF NOT EXISTS `products` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(255) NOT NULL,
  `image` VARCHAR(255) NOT NULL,
  `price` DECIMAL(10,2) NOT NULL,
  `duration` VARCHAR(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `orders` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `order_number` VARCHAR(50) NOT NULL,
  `customer_name` VARCHAR(255) NOT NULL,
  `phone` VARCHAR(20) NOT NULL,
  `email` VARCHAR(255) NOT NULL,
  `product_name` VARCHAR(255) NOT NULL,
  `duration` VARCHAR(50) NOT NULL,
  `price` DECIMAL(10,2) NOT NULL,
  `payment_method` VARCHAR(50) NOT NULL,
  `trx_id` VARCHAR(100) NOT NULL,
  `status` VARCHAR(20) DEFAULT 'Paid',
  `order_time` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert Default Demo Products
INSERT INTO `products` (`name`, `image`, `price`, `duration`) VALUES
('Netflix Premium 4K UltraHD', 'https://images.unsplash.com/photo-1574375927938-d5a98e8edd86?w=500', 250.00, '1'),
('Amazon Prime Video VIP', 'https://images.unsplash.com/photo-1517604931442-7e0c8ed2963c?w=500', 650.00, '3'),
('Disney+ Hotstar Premium', 'https://images.unsplash.com/photo-1594909122845-11baa439b7bf?w=500', 1100.00, '6'),
('SonyLIV Premium Annual', 'https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7?w=500', 1999.00, '12');
