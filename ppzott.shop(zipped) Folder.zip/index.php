<?php
include 'config.php';
$products = $conn->query("SELECT * FROM products ORDER BY id DESC");
?>
<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $website_name; ?> | Best OTT Subscription Store</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .glow-effect:hover {
            box-shadow: 0 0 20px rgba(245, 158, 11, 0.4);
            border-color: #f59e0b;
        }
    </style>
</head>
<body class="bg-slate-950 text-gray-100 font-sans selection:bg-amber-500 selection:text-black">

    <!-- Header Navigation -->
    <header class="bg-slate-900/90 backdrop-blur border-b border-amber-500/30 sticky top-0 z-50 shadow-2xl">
        <div class="container mx-auto px-4 py-4 flex flex-col sm:flex-row justify-between items-center gap-4">
            <a href="index.php" class="flex items-center gap-2">
                <span class="text-2xl font-black tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-amber-400 to-orange-500">
                    PRITOM PREMIUM ZONE-OTT
                </span>
            </a>
            <div class="flex items-center gap-4">
                <a href="<?php echo $main_website; ?>" target="_blank" class="bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-slate-950 font-extrabold px-5 py-2.5 rounded-lg shadow-lg shadow-amber-500/20 transition-all duration-300 transform hover:scale-105">
                    <i class="fas fa-external-link-alt mr-2"></i> MAIN WEBSITE
                </a>
            </div>
        </div>
    </header>

    <!-- Hero Section -->
    <section class="relative py-20 overflow-hidden bg-gradient-to-b from-slate-900 to-slate-950 text-center">
        <div class="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(245,158,11,0.08)_0,transparent_100%)]"></div>
        <div class="container mx-auto px-4 relative z-10">
            <span class="bg-amber-500/10 text-amber-400 text-xs font-bold uppercase tracking-widest px-4 py-1.5 rounded-full border border-amber-500/20 inline-block mb-4">
                Premium Instant Automated Delivery
            </span>
            <h1 class="text-4xl md:text-6xl font-black mb-6 tracking-tight leading-none">
                আপনার পছন্দের <span class="text-transparent bg-clip-text bg-gradient-to-r from-amber-400 to-orange-400">OTT সাবস্ক্রিপশন</span> এক ক্লিকেই!
            </h1>
            <p class="text-gray-400 max-w-2xl mx-auto text-base md:text-lg">
                bKash ও Nagad ভেরিফাইড পেমেন্ট গেটওয়ের মাধ্যমে মুহূর্তেই কিনুন সাবস্ক্রিপশন অ্যাকাউন্ট। কোনো প্রকার হ্যাসেল ছাড়াই অটোমেটিক ডেলিভারি।
            </p>
        </div>
    </section>

    <!-- Product Grid Section -->
    <main class="container mx-auto px-4 py-12">
        <div class="flex items-center justify-between mb-8 border-b border-slate-800 pb-4">
            <h2 class="text-2xl font-bold flex items-center gap-3">
                <i class="fas fa-fire text-amber-500"></i> আমাদের প্যাকেজ সমূহ
            </h2>
            <span class="text-sm text-gray-400"><?php echo $products->num_rows; ?>টি প্যাকেজ উপলব্ধ</span>
        </div>

        <?php if($products->num_rows > 0): ?>
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                <?php while($row = $products->fetch_assoc()): ?>
                    <div class="bg-slate-900 rounded-2xl border border-slate-800 overflow-hidden flex flex-col justify-between transition-all duration-300 glow-effect">
                        <div class="relative group">
                            <img src="<?php echo htmlspecialchars($row['image']); ?>" alt="<?php echo htmlspecialchars($row['name']); ?>" class="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-500">
                            <span class="absolute top-3 right-3 bg-slate-950/80 backdrop-blur text-amber-400 text-xs font-bold px-3 py-1 rounded-full border border-amber-500/30">
                                <i class="far fa-clock mr-1"></i> <?php echo htmlspecialchars($row['duration']); ?> মাস মেয়াদ
                            </span>
                        </div>
                        
                        <div class="p-5 flex-grow">
                            <h3 class="text-lg font-bold text-white mb-2 line-clamp-1">
                                <?php echo htmlspecialchars($row['name']); ?>
                            </h3>
                            <div class="flex items-baseline gap-1 mt-4">
                                <span class="text-3xl font-black text-green-400">৳<?php echo number_format($row['price'], 0); ?></span>
                                <span class="text-xs text-gray-500">/ এককালীন</span>
                            </div>
                        </div>

                        <div class="p-5 pt-0">
                            <form action="payment.php" method="POST">
                                <input type="hidden" name="product_id" value="<?php echo $row['id']; ?>">
                                <button type="submit" name="buy_now" class="w-full bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-slate-950 font-black py-3 px-4 rounded-xl shadow-lg transition-all duration-200 cursor-pointer flex items-center justify-center gap-2">
                                    <i class="fas fa-shopping-cart"></i> Buy & Add to Cart
                                </button>
                            </form>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        <?php else: ?>
            <div class="text-center py-12 bg-slate-900 rounded-2xl border border-slate-800">
                <i class="fas fa-box-open text-5xl text-gray-600 mb-3"></i>
                <p class="text-gray-400">আপাতত কোনো প্রোডাক্ট যোগ করা হয়নি। শীঘ্রই আসছে!</p>
            </div>
        <?php endif; ?>
    </main>

    <!-- Footer Area -->
    <footer class="bg-slate-950 border-t border-slate-900 pt-16 pb-8 text-gray-400">
        <div class="container mx-auto px-4 grid grid-cols-1 md:grid-cols-3 gap-12 mb-12">
            <div>
                <h4 class="text-white font-bold text-lg mb-4 flex items-center gap-2">
                    <span class="w-1.5 h-5 bg-amber-500 rounded-full"></span> যোগাযোগ ও ঠিকানা
                </h4>
                <ul class="space-y-3 text-sm">
                    <li><i class="fas fa-user-tie text-amber-500 mr-2.5 w-4"></i>ওনার: <?php echo $owner_name; ?></li>
                    <li><i class="fas fa-map-marker-alt text-amber-500 mr-2.5 w-4"></i><?php echo $address; ?></li>
                    <li><i class="fas fa-phone-alt text-amber-500 mr-2.5 w-4"></i><?php echo $contact_num; ?></li>
                    <li><i class="fas fa-envelope text-amber-500 mr-2.5 w-4"></i><?php echo $contact_email; ?></li>
                </ul>
            </div>
            <div>
                <h4 class="text-white font-bold text-lg mb-4 flex items-center gap-2">
                    <span class="w-1.5 h-5 bg-amber-500 rounded-full"></span> সোশ্যাল মিডিয়া ও কমিউনিটি
                </h4>
                <div class="flex flex-wrap gap-3">
                    <a href="<?php echo $fb_page; ?>" target="_blank" class="bg-slate-900 hover:bg-blue-600 text-white w-10 h-10 rounded-lg flex items-center justify-center border border-slate-800 transition-colors"><i class="fab fa-facebook-f"></i></a>
                    <a href="<?php echo $insta_page; ?>" target="_blank" class="bg-slate-900 hover:bg-pink-600 text-white w-10 h-10 rounded-lg flex items-center justify-center border border-slate-800 transition-colors"><i class="fab fa-instagram"></i></a>
                    <a href="<?php echo $wa_group; ?>" target="_blank" class="bg-slate-900 hover:bg-green-600 text-white w-10 h-10 rounded-lg flex items-center justify-center border border-slate-800 transition-colors"><i class="fab fa-whatsapp"></i></a>
                    <a href="<?php echo $tg_group; ?>" target="_blank" class="bg-slate-900 hover:bg-blue-500 text-white w-10 h-10 rounded-lg flex items-center justify-center border border-slate-800 transition-colors"><i class="fab fa-telegram-plane"></i></a>
                </div>
                <p class="text-xs text-gray-500 mt-4">আমাদের অফিশিয়াল গ্রুপ ও পেইজে জয়েন হয়ে আপডেট থাকুন।</p>
            </div>
            <div>
                <h4 class="text-white font-bold text-lg mb-4 flex items-center gap-2">
                    <span class="w-1.5 h-5 bg-amber-500 rounded-full"></span> আমাদের মূল হাব
                </h4>
                <p class="text-sm mb-4">আমাদের সমস্ত প্রিমিয়াম সার্ভিস ও ডিল দেখতে মেইন ওয়েবসাইট ভিজিট করুন।</p>
                <a href="<?php echo $main_website; ?>" target="_blank" class="text-amber-400 hover:text-amber-300 font-bold underline block text-lg tracking-wide">
                    www.pritompremiumzone.com
                </a>
            </div>
        </div>
        <div class="container mx-auto px-4 border-t border-slate-900 pt-6 text-center text-xs text-gray-600 flex flex-col sm:flex-row justify-between items-center gap-4">
            <p>&copy; 2026 <?php echo $website_name; ?>. All Rights Reserved.</p>
            <p>Domain: <a href="https://<?php echo $domain_name; ?>" target="_blank" class="hover:underline text-gray-500"><?php echo $domain_name; ?></a></p>
        </div>
    </footer>

    <!-- Floating WhatsApp Widget Button -->
    <a href="https://wa.me/<?php echo filter_var($whatsapp_num, FILTER_SANITIZE_NUMBER_INT); ?>" target="_blank" class="fixed bottom-6 right-6 bg-green-500 hover:bg-green-600 text-white w-14 h-14 rounded-full flex items-center justify-center text-3xl shadow-2xl transition-all duration-300 hover:scale-110 z-50 animate-bounce" title="WhatsApp এ মেসেজ দিন">
        <i class="fab fa-whatsapp"></i>
    </a>

</body>
</html>
