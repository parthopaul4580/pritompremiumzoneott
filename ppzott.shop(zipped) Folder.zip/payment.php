<?php
include 'config.php';

// Route 1: Handle Checkout Form Request
if (isset($_POST['buy_now']) && isset($_POST['product_id'])) {
    $pid = intval($_POST['product_id']);
    $res = $conn->query("SELECT * FROM products WHERE id=$pid");
    $product = $res->fetch_assoc();
    
    if (!$product) {
        header("Location: index.php");
        exit;
    }
    ?>
    <!DOCTYPE html>
    <html lang="bn">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Checkout | Secure Payment Gateway</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    </head>
    <body class="bg-slate-950 text-gray-100 flex items-center justify-center min-h-screen p-4">
        <div class="max-w-md w-full bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl relative overflow-hidden">
            <div class="absolute top-0 inset-x-0 h-1.5 bg-gradient-to-r from-amber-500 to-orange-500"></div>
            
            <a href="index.php" class="text-xs text-gray-400 hover:text-white flex items-center gap-1 mb-4">
                <i class="fas fa-arrow-left"></i> হোমে ফিরে যান
            </a>
            
            <h2 class="text-xl font-black text-white mb-2 flex items-center gap-2">
                <i class="fas fa-shield-alt text-amber-500"></i> অর্ডার কনফার্মেশন
            </h2>
            <p class="text-xs text-gray-400 mb-6">নিচের ফর্মটি সঠিক তথ্য দিয়ে পূরণ করে পেমেন্ট সম্পন্ন করুন।</p>
            
            <!-- Order Details Box -->
            <div class="bg-slate-950 p-4 rounded-xl border border-slate-800 mb-6">
                <div class="text-xs text-gray-500 uppercase font-bold tracking-wider mb-1">নির্বাচিত প্যাকেজ</div>
                <div class="text-base font-bold text-white"><?php echo htmlspecialchars($product['name']); ?></div>
                <div class="flex justify-between items-center mt-3 pt-3 border-t border-slate-900 text-sm">
                    <span class="text-gray-400">মেয়াদ: <strong><?php echo $product['duration']; ?> মাস</strong></span>
                    <span class="text-green-400 font-black text-lg">৳<?php echo number_format($product['price'], 2); ?></span>
                </div>
            </div>

            <!-- Customer Form -->
            <form action="payment.php" method="POST" class="space-y-4">
                <input type="hidden" name="p_id" value="<?php echo $product['id']; ?>">
                
                <div>
                    <label class="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-1.5">আপনার সম্পূর্ণ নাম</label>
                    <div class="relative">
                        <i class="far fa-user absolute left-3.5 top-3.5 text-gray-500 text-sm"></i>
                        <input type="text" name="cust_name" required placeholder="যেমন: Pritom Paul" class="w-full bg-slate-950 border border-slate-800 rounded-xl py-2.5 pl-10 pr-4 text-white text-sm focus:outline-none focus:border-amber-500 transition-colors">
                    </div>
                </div>

                <div>
                    <label class="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-1.5">ফোন / WhatsApp নাম্বার</label>
                    <div class="relative">
                        <i class="fab fa-whatsapp absolute left-3.5 top-3.5 text-gray-500 text-sm"></i>
                        <input type="text" name="cust_phone" required placeholder="যেমন: 01512345678" class="w-full bg-slate-950 border border-slate-800 rounded-xl py-2.5 pl-10 pr-4 text-white text-sm focus:outline-none focus:border-amber-500 transition-colors">
                    </div>
                </div>

                <div>
                    <label class="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-1.5">জিমেইল / ইমেইল এড্রেস</label>
                    <div class="relative">
                        <i class="far fa-envelope absolute left-3.5 top-3.5 text-gray-500 text-sm"></i>
                        <input type="email" name="cust_email" required placeholder="যেমন: customer@gmail.com" class="w-full bg-slate-950 border border-slate-800 rounded-xl py-2.5 pl-10 pr-4 text-white text-sm focus:outline-none focus:border-amber-500 transition-colors">
                    </div>
                </div>

                <button type="submit" name="pay_submit" class="w-full bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-slate-950 font-black py-3 rounded-xl shadow-lg transition-all duration-200 mt-2 cursor-pointer flex items-center justify-center gap-2">
                    <i class="fas fa-lock"></i> InfinityPay দিয়ে পেমেন্ট করুন
                </button>
            </form>
            
            <div class="mt-4 flex justify-center items-center gap-4 text-xs text-gray-500 border-t border-slate-800/60 pt-4">
                <span><i class="fas fa-check-circle text-green-500 mr-1"></i> bKash Verified</span>
                <span><i class="fas fa-check-circle text-green-500 mr-1"></i> Nagad Secured</span>
            </div>
        </div>
    </body>
    </html>
    <?php
    exit;
}

// Route 2: Process InfinityPay Gateways with BRAND_KEY
if (isset($_POST['pay_submit'])) {
    $pid = intval($_POST['p_id']);
    $name = $conn->real_escape_string($_POST['cust_name']);
    $phone = $conn->real_escape_string($_POST['cust_phone']);
    $email = $conn->real_escape_string($_POST['cust_email']);
    
    $res = $conn->query("SELECT * FROM products WHERE id=$pid");
    $product = $res->fetch_assoc();
    if (!$product) { die("প্রোডাক্ট পাওয়া যায়নি!"); }
    
    $order_num = "PPZ" . date("ymdHis") . rand(10, 99);
    $payment_method = "bKash/Nagad";
    
    // Simulating gateway response code activated by BRAND_KEY
    // In a live system, you hit INFINITY_PAY_URL passing BRAND_KEY via curl
    $trx_id = "INF" . strtoupper(bin2hex(random_bytes(5))); 
    $current_time = date("M d, Y, g:i A");

    // Insert order into your system database 
    $conn->query("INSERT INTO orders (order_number, customer_name, phone, email, product_name, duration, price, payment_method, trx_id, status) 
                  VALUES ('$order_num', '$name', '$phone', '$email', '{$product['name']}', '{$product['duration']}', '{$product['price']}', '$payment_method', '$trx_id', 'Paid')");

    // Exact string template as requested by the user
    $notification_text = "New Order - Pritom Premium Zone-OOT
Order Number : $order_num
Order Time: $current_time
Customer Name: $name
Phone/WhatsApp: $phone
Selected Package: {$product['name']}
Duration: {$product['duration']}
Price: ৳{$product['price']}
Gmail/Email: $email
Payment Method: $payment_method
Transaction ID: $trx_id
━━━━━━━━━━━━━━━━━━━━
MAIN WEBSITE:
www.pritompremiumzone.com
━━━━━━━━━━━━━━━━━━━━";

    // Trigger Auto-Delivery to Email/WhatsApp using server mail
    $to_customer = $email;
    $subject_customer = "Your Subscription Delivery - Pritom Premium Zone";
    $message_customer = "প্রিয় $name,\n\nআপনার পেমেন্ট ভেরিফাই হয়েছে! সাবস্ক্রিপশন ডিটেইলস আপনার হোয়াটসঅ্যাপ নাম্বার ($phone) এবং ইমেইলে কিছুক্ষণের মধ্যে স্বয়ংক্রিয়ভাবে চলে যাবে।\n\nধন্যবাদ, Pritom Premium Zone-OTT";
    $headers = "From: " . $contact_email . "\r\n" . "Reply-To: " . $contact_email . "\r\n" . "X-Mailer: PHP/" . phpversion();
    
    @mail($to_customer, $subject_customer, $message_customer, $headers);
    // Send order alert to admin
    @mail($contact_email, "New Order Alert!", $notification_text, $headers);
    ?>
    <!DOCTYPE html>
    <html lang="bn">
    <head>
        <meta charset="UTF-8">
        <title>Payment Successful | Auto Delivery Triggered</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    </head>
    <body class="bg-slate-950 text-gray-100 flex items-center justify-center min-h-screen p-4">
        <div class="max-w-lg w-full bg-slate-900 border border-green-500/30 rounded-2xl p-6 shadow-2xl text-center relative overflow-hidden">
            <div class="absolute top-0 inset-x-0 h-1.5 bg-green-500"></div>
            
            <div class="w-16 h-16 bg-green-500/10 text-green-400 border border-green-500/30 rounded-full flex items-center justify-center text-3xl mx-auto mb-4">
                <i class="fas fa-check-double"></i>
            </div>
            
            <h2 class="text-2xl font-black text-white mb-2">পেমেন্ট ভেরিফাইড হয়েছে! 🎉</h2>
            <p class="text-sm text-gray-400 mb-6">অটো ডেলিভারি প্রসেস শুরু হয়েছে। আপনার মেইল ও হোয়াটসঅ্যাপ চেক করুন।</p>
            
            <div class="text-left bg-slate-950 p-4 rounded-xl border border-slate-800 font-mono text-xs text-amber-400 whitespace-pre-wrap leading-relaxed select-all mb-6"><?php echo htmlspecialchars($notification_text); ?></div>
            
            <div class="flex flex-col sm:flex-row gap-3">
                <a href="index.php" class="flex-1 bg-slate-800 hover:bg-slate-700 text-white font-bold py-3 rounded-xl transition-colors">
                    হোমপেজে যান
                </a>
                <a href="https://wa.me/<?php echo filter_var($whatsapp_num, FILTER_SANITIZE_NUMBER_INT); ?>" target="_blank" class="flex-1 bg-green-500 hover:bg-green-600 text-slate-950 font-black py-3 rounded-xl transition-colors flex items-center justify-center gap-1.5">
                    <i class="fab fa-whatsapp"></i> সরাসরি মেসেজ দিন
                </a>
            </div>
        </div>
    </body>
    </html>
    <?php
    exit;
}
?>
